# coding: utf-8
from distutils.core import setup
setup(name='webscrap',
    version='0.1.0',
    description='Webscrapping for humans',
    author='Lee Seongjoo',
    author_email='seongjoo@codeabasic.co',
    package_dir={'webscrap': ''},
    packages=['webscrap']
    )
